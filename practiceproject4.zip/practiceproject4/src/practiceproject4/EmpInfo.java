package practiceproject4;

public class EmpInfo {
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}
}

