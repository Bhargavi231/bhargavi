package accessmodifier;

public class defAccessSpecifier 
{
	public static void main(String[] args) 
	{
		System.out.println("default access specifier");
		accessSpecifier1 obj=new accessSpecifier1();
		obj.display();
			
	}		
}
