package accessmodifier;

public class accessSpecifier1 
{
	void display()
	{
		System.out.println("you are using default access specifier");
	}

}
