package accessmodifier;

class priAccessSpecifier 
{
	private void display1()
	{
		System.out.println("you are using private access specifier");
	}
}
