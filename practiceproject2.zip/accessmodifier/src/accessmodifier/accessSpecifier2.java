package accessmodifier;

public class accessSpecifier2 
{
	public static void main(String[] args)
	{
		System.out.println("private access specifier");
		priAccessSpecifier obj1=new priAccessSpecifier();
		
	}

}
