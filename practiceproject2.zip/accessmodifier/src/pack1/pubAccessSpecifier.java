package pack1;

public class pubAccessSpecifier
{
	public void display()
	{
		System.out.println("this is public access specifier");
	}

}
