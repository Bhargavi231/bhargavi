package pack1;

public class proAccessSpecifier {
	protected void display()
	{
		System.out.println("this is protected access specifier");
	}
}
