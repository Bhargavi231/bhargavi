package pack2;
import pack1.proAccessSpecifier;

public class accessSpecifier3 extends proAccessSpecifier
{
	public static void main(String[] args)
	{
		accessSpecifier3 obj=new accessSpecifier3();
		obj.display();
		
	}
	

}
