/**
 * 
 */
/**
 * 
 */
module binarysearch2 {
}