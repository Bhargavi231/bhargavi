/**
 * 
 */
/**
 * 
 */
module ElementsInStack {
}