package project3;

 class Sync {

    public void send(String msg) 
    { 
        System.out.println("Sending\t"  + msg ); 
        try
        { 
            Thread.sleep(1000); 
        } 
        catch (Exception e) 
        { 
            System.out.println("Thread  interrupted."); 
        } 
        System.out.println("\n" + msg + "Sent"); 
    } 
} 
class ThreadedSend extends Thread 
{ 
    private String msg; 
    private Thread t; 
    Sync Sync; 
    ThreadedSend(String m,  Sync obj) 
    { 
        msg = m; 
        Sync = obj; 
    } 
  
    public void run() 
    {  
        synchronized(Sync) 
        { 
            Sync.send(msg); 
        } 
    } 
} 


