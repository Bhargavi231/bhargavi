/**
 * 
 */
/**
 * 
 */
module rotateanarray {
}